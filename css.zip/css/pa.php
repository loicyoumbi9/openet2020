<?php
	$nom = 'Pamela';
	$texte = 'amoureux';
	echo '<stron> Je suis '. $texte . 'de toi'. $nom. '</stron>'
?>