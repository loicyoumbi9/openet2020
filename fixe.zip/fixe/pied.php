<footer class="pied">
	<p> copyright &copy; openNetwork 2016 Tous droits réservés</p>
</footer>