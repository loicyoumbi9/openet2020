<header class="en_tete">
	<img src="images/image_logo.jpg" id="logo"/>
	<nav class="lien">
		<a href="index.php" id="lien_page">  Deconnexion(<?php echo $nom;?> )</a>
		<a href="profil.php" id="lien_page"> Profils </a>
		<a href="messages.php" id="lien_page"> Messages </a>
		<a href="contacts.php" id="lien_page"> Contacts </a>
		<a href="acceuil.php" id="lien_page"> Acceuil </a>	
	</nav>
</header>